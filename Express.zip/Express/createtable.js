const mysql = require('mysql');
const dotenv = require('dotenv');
dotenv.config();
 
// ACHTUNG MYSQL8
// ALTER USER 'todoapp' IDENTIFIED WITH mysql_native_password BY 'todoapp';
 
let connection = mysql.createConnection({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_Name,
 
});
 
connection.connect((err) => {
    if (err) return console.error(err.message);
    console.log('Connected to MYSQL');
 
 
    // alles ok mit der Verbindung
    let sql = `create table if not exists todos(
        id int primary key auto_increment,
        title varchar(255) not null,
        completed bool not null default false
    );`;
 
    connection.query(sql, (err, results, fields) => {
        if (err) return console.error(err.message);
        console.log(results);
    })
 
    sql = `insert into todos(title,completed) values ('Learn SWP',true)`;
    connection.query(sql, (err, results, fields) => {
        if (err) return console.error(err.message);
        console.log(results);
    })
 
    sql = `insert into todos (title,completed) values (?,?);`;
    let todo = ['xxx soll ich macha', true];
    connection.query(sql, todo, (err, results, fields) => {
        if (err) return console.error(err.message);
        console.log(results);
    })
 
    sql = `select * from todos where title like ?;`;
    let suche = ['%ich%'];
    connection.query(sql, suche, (err, results, fields) => {
        if (err) return console.error(err.message);
        console.log(results);
        results.map(value => {
            console.log(value.id + " " + value.title + " " + value.completed);
        })
    })
 
    connection.end((err) => {
        if (err) return console.log(err.message)
        console.log("Close connectoin");
    }
    );
}
);