const cors = require('cors');
const express = require('express');
const mysql = require('mysql2/promise');
const app = express();
const dotenv = require ('dotenv');
dotenv.config();
const PORT = 3000;
const jwt = require('jsonwebtoken');
const TOKEN_SECRET = process.env.TOKEN_SECRET;


//token

 
/// AJV
const createValidator = require('./validateRequestBody');

const todoSchema = {
  type: "object",
  properties: {
    title: { type: "string" },
    completed: { type: "boolean" }
  },
  required: ["title", "completed"],
  additionalProperties: false
};

const validateTodo = createValidator(todoSchema);

// Middleware
 
// Create an async pool object with promisified methods
 
const pool = mysql.createPool({
  connectionLimit: 100,
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
})
 
async function query(sql, params) {
  try {
    const [rows, fields] = await pool.execute(sql, params);
    return rows;
  } catch (error) {
    throw error;
  }
}
 
// Function to check the connection
async function checkConnection() {
  try {
    // Execute a simple query to check the connection
    await pool.query('SELECT 1');
    console.log('Connected to the MySQL server.');
  } catch (err) {
    console.error('Error connecting to MySQL server:', err);
  } finally {
    // Close the connection pool
  }
}
 
// Call the function to check the connection
checkConnection();
 
app.use(cors());
// Check falls Body auch wirklich ein JSON-Format!!
app.use((req, res, next) => {
  express.json()(req, res, err => {
    if (err) {
      return res.status(400).send({
        message: "Could not parse JSON"
      });
    }
    next();
  })
});
app.use(express.urlencoded({ extended: true }));
 
 
// --- Kunde ---
// GET
app.get('/todo',authenticateToken, async function (req, res) {
  try {
    const sql = `SELECT * FROM todos `;
    var todos = await query(sql);
    //console.log(todos);
    if (todos.length == 0) {
      res.status(404).json({
        status: 404,
        message: "keine Todos gefunden"
      });
      return;
    }
    console.log(todos);
    var row = todos.length;
    res.status(200).json({
      status: 200,
      todos,
      row
    });
  } catch (err) {
    res.status(500).send({
      status: 500,
      message: err
    });
  }
  return;
});

// GET by ID

app.get('/todo/:id',authenticateToken, async function (req, res) {
  try {
    const { id } = req.params;

    // Überprüfen, ob die id eine Zahl ist
    if (isNaN(id)) {
      res.status(400).json({
        status: 400,
        message: "Ungültige id: id muss eine Zahl sein"
      });
      return;
    }
    
    const sql = `SELECT * FROM todos WHERE id = ?`;
    var todos = await query(sql, [id]);
    if (todos.length == 0) {
      res.status(404).json({
        status: 404,
        message: "Todo nicht gefunden"
      });
      return;
    }
    res.status(200).json({
      status: 200,
      todos
    });
  } catch (err) {
    res.status(500).send({
      status: 500,
      message: err
    });
  }
  return;
} );
 
// POST 
app.post('/todo',authenticateToken, validateTodo, async function (req, res) {
  try {
    const { title, completed } = req.body;
    const sql = `INSERT INTO todos (title, completed) VALUES (?, ?)`;
    await query(sql, [title, completed]);
    res.status(201).json({
      status: 201,
      message: "Todo erfolgreich hinzugefügt"
    });
  } catch (err) {
    res.status(500).send({
      status: 500,
      message: err
    });
  }
});

// PUT 
app.put('/todo/:id',authenticateToken,validateTodo, async function (req, res) {
  try {
    const { id } = req.params;
    // Überprüfen, ob die id eine Zahl ist
    if (isNaN(id)) {
      res.status(400).json({
        status: 400,
        message: "Ungültige id: id muss eine Zahl sein"
      });
      return;
    }

    const { title, completed } = req.body;
    
    const sql = `UPDATE todos SET title = ?, completed = ? WHERE id = ?`;
    await query(sql, [title, completed, id]);
    res.status(200).json({
      status: 200,
      message: "Todo erfolgreich aktualisiert"
    });
  } catch (err) {
    res.status(500).send({
      status: 500,
      message: err
    });
  }
});

// DELETE 
app.delete('/todo/:id', authenticateToken,async function (req, res) {
  try {
    
    const { id } = req.params;
    // Überprüfen, ob die id eine Zahl ist
    if (isNaN(id)) {
      res.status(400).json({
        status: 400,
        message: "Ungültige id: id muss eine Zahl sein"
      });
      return;
    }

    const sql = `DELETE FROM todos WHERE id = ?`;
    await query(sql, [id]);
    res.status(200).json({
      status: 200,
      message: "Todo erfolgreich gelöscht"
    });
  } catch (err) {
    res.status(500).send({
      status: 500,
      message: err
    });
  }
});

// LOGIN
app.get('/user/login', async function (req, res) {
  data = req.body;
  let sql = "select username, password from user where username = ? and password = ?";
  const values = [req.body.username, req.body.password];
  try {
    const results = await query(sql, values);
    if (results.length === 0) {
      return res.status(409).json({ status: 409, message: "username oder password falsch" });
    }
    const token = generateAccessToken({ username: req.body.username });
    return res.status(201).json({
      token: token,
      status: 201,
      message: "erfolgreich eingeloggt und token erstellt"
    })
  } catch (err) {
    console.error("Database error:", err);
    return res.status(500).json({ status: 500, message: "Datenbankfehler: " + err.message });
  }
})


// Token für User erstellen
function generateAccessToken(username) {
  return jwt.sign(username, TOKEN_SECRET, { expiresIn: '1800s' });
}

//Token Überprüfung
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization']
  const token = authHeader && authHeader.split(' ')[1]
  if (!token) return res.status(401).json({ message: "kein token gefunden", status: 401 })
  jwt.verify(token, TOKEN_SECRET, (err, user) => {
    if (err) return res.status(403).json({ message: "falscher token", status: 403 })
    req.user = user
    next()
  })
}

// LISTEN
 
app.listen(PORT, () => {
  console.log(`App server now listening on port ${PORT}`);
});