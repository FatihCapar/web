const Ajv = require('ajv');
const ajv = new Ajv();

function createValidator(schema) {
  const validate = ajv.compile(schema);

  return function validateRequestBody(req, res, next) {
    const valid = validate(req.body);
    if (!valid) {
      res.status(400).send({
        status: 400,
        message: "Ungültige Anforderungsdaten",
        errors: validate.errors
      });
    } else {
      next();
    }
  };
}

module.exports = createValidator;