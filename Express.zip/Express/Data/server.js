const puppeteer = require('puppeteer');


async function login(url, username, password) {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.goto(url);
  // Replace '#username' and '#password' with the correct selectors for the username and password fields.
  // Replace '#loginButton' with the selector for the login button.
  await page.type('[name="username"]', username);
  await page.type('#password', password);
  await page.click('#loginButton');
  await page.waitForNavigation(); // Wait for the next page to load.
  // Here you check for a condition that indicates a successful login.
  // This could be the presence of a logout button, a specific URL, or specific content only visible to logged-in users.
  // This is a generic example; you'll need to customize the success check for your specific case.
  const loginSuccessful = await page.evaluate(() => {
    const logoutButton = document.querySelector('#logoutButton');
    return Boolean(logoutButton);
  });
  await browser.close();
  return loginSuccessful;
}
const url = 'https://example.com/login'; // Replace with the actual login URL
const username = 'yourUsername'; // Replace with the actual username
const password = 'yourPassword'; // Replace with the actual password
login(url, username, password)
  .then(loginSuccessful => {
    if (loginSuccessful) {
      console.log('Login successful');
    } else {
      console.log('Login failed');
    }
  })
  .catch(error => {
    console.error('An error occurred:', error);
  });
