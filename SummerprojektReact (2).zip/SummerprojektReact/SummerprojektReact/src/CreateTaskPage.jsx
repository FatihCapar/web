import React from 'react';
import CreateTask from './CreateTask';

const CreateTaskPage = () => {
  return (
    <div>
      <h1>Aufgabe erstellen</h1>
      <CreateTask />
    </div>
  );
}

export default CreateTaskPage;
