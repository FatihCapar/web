import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCurrentUser } from './UserContext'; // Importieren Sie den useCurrentUser Hook
import './Login.css';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [timer, setTimer] = useState(0);
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [waiting, setWaiting] = useState(false);
  const navigate = useNavigate();
  const { setCurrentUser } = useCurrentUser(); // Verwenden Sie den Hook, um den aktuellen Benutzer zu setzen

  const handleSubmit = (event) => {
    event.preventDefault();

    if (waiting) {
      return;
    }

    const requiredWaitTime = Math.pow(2, failedAttempts) * 1000;

    fetch('/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    })
    .then(response => response.json())
    .then(data => {
      console.log('Empfangene Benutzerdaten:',data);
      if (data.success) {
        setCurrentUser(data.user) // Setzen Sie den aktuellen Benutzer mit ID und Benutzernam
        navigate(data.redirectUrl);
        console.log('derzeitiger Benutzer:',username);
      } else {
        setErrorMessage(data.message);
        setFailedAttempts(failedAttempts + 1);
        showCountdown(requiredWaitTime / 1000);
      }
    })
    .catch(error => {
      console.error('Fehler:', error);
      setErrorMessage('Ein Fehler ist aufgetreten. Bitte versuchen Sie es später erneut.');
    });
  };

  const showCountdown = (seconds) => {
    setWaiting(true);
    setTimer(seconds);

    const interval = setInterval(() => {
      seconds -= 1;
      setTimer(seconds);

      if (seconds <= 0) {
        clearInterval(interval);
        setWaiting(false);
      }
    }, 1000);
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Benutzername:
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </label>
        <label>
          Passwort:
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </label>
        <button type="submit" disabled={waiting}>Anmelden</button>
      </form>
      {errorMessage && <div className="error-message">{errorMessage}</div>}
      {waiting && <div className="timer">Bitte warten Sie {timer} Sekunden, bevor Sie es erneut versuchen.</div>}
    </div>
  );
}

export default Login;
